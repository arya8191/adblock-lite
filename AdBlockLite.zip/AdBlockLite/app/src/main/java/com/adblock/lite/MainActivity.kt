package com.adblock.lite

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var toggle: Button
    private lateinit var status: TextView
    private lateinit var editor: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 18f }
        toggle = Button(this)
        val save = Button(this).apply { text = "Simpan daftar" }
        editor = EditText(this).apply {
            setText(Blocklist.raw(this@MainActivity))
            gravity = Gravity.TOP
            textSize = 13f
            typeface = Typeface.MONOSPACE
        }
        root.addView(status)
        root.addView(toggle)
        root.addView(save)
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        toggle.setOnClickListener {
            if (AdVpnService.running) {
                stopService(Intent(this, AdVpnService::class.java))
            } else {
                Blocklist.save(this, editor.text.toString())
                val i = VpnService.prepare(this)
                if (i != null) startActivityForResult(i, 1) else startVpn()
            }
            toggle.postDelayed({ refresh() }, 600)
        }
        save.setOnClickListener {
            Blocklist.save(this, editor.text.toString())
            if (AdVpnService.running) startVpn() // service reload daftar
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) startVpn()
        toggle.postDelayed({ refresh() }, 600)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startVpn() = startService(Intent(this, AdVpnService::class.java))

    private fun refresh() {
        val on = AdVpnService.running
        status.text = if (on) "Status: AKTIF" else "Status: MATI"
        toggle.text = if (on) "Matikan" else "Aktifkan"
    }
}
