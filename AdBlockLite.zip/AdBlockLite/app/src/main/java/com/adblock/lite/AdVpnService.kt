package com.adblock.lite

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Blocklist {
    private const val KEY = "domains"

    val DEFAULT = """
# Satu domain per baris. Subdomain ikut keblokir.
doubleclick.net
googleadservices.com
googlesyndication.com
adservice.google.com
admob.google.com
app-measurement.com
applovin.com
applvn.com
unityads.unity3d.com
ads.unity3d.com
mopub.com
adcolony.com
vungle.com
chartboost.com
inmobi.com
inmobicdn.net
ironsrc.com
supersonicads.com
startapp.com
smaato.net
tapjoy.com
fyber.com
mintegral.com
pangleglobal.com
an.facebook.com
pubmatic.com
rubiconproject.com
adnxs.com
criteo.com
taboola.com
outbrain.com
moatads.com
amazon-adsystem.com
adsrvr.org
""".trimIndent()

    private fun prefs(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun raw(c: Context): String = prefs(c).getString(KEY, DEFAULT) ?: DEFAULT
    fun save(c: Context, text: String) = prefs(c).edit().putString(KEY, text).apply()
    fun load(c: Context): Set<String> = raw(c).lines()
        .map { it.trim().lowercase() }
        .filter { it.isNotEmpty() && !it.startsWith("#") }
        .toSet()
}

class AdVpnService : VpnService() {
    companion object {
        @Volatile var running = false
        private const val FAKE_DNS = "10.0.0.1"
        private const val UPSTREAM = "1.1.1.1"
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val pool: ExecutorService = Executors.newFixedThreadPool(8)
    @Volatile private var blocked: Set<String> = emptySet()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        blocked = Blocklist.load(this) // selalu reload daftar
        if (tun == null) start()
        return START_STICKY
    }

    private fun start() {
        val fd = Builder()
            .setSession("AdBlock Lite")
            .addAddress("10.0.0.2", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32) // hanya trafik DNS yang masuk tunnel
            .setBlocking(true)
            .establish() ?: return
        tun = fd
        running = true
        worker = Thread {
            val input = FileInputStream(fd.fileDescriptor)
            val output = FileOutputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            while (running) {
                val n = try { input.read(buf) } catch (e: Exception) { break }
                if (n > 0) handle(buf.copyOf(n), output)
            }
        }.also { it.start() }
    }

    private fun handle(pkt: ByteArray, out: FileOutputStream) {
        if (pkt.size < 28 || (pkt[0].toInt() shr 4) != 4) return // IPv4 saja
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17) return                          // UDP saja
        if (u16(pkt, ihl + 2) != 53) return                       // port DNS
        val total = minOf(u16(pkt, 2), pkt.size)
        if (total < ihl + 8 + 12) return
        val dns = pkt.copyOfRange(ihl + 8, total)
        val (name, qEnd) = parseName(dns) ?: return

        if (isBlocked(name) && dns.size >= qEnd + 4) {
            val r = dns.copyOf(qEnd + 4) // header + question saja
            r[2] = 0x81.toByte(); r[3] = 0x83.toByte() // response, NXDOMAIN
            for (k in 6..11) r[k] = 0
            reply(pkt, ihl, r, out)
        } else {
            pool.execute {
                try {
                    DatagramSocket().use { s ->
                        protect(s) // biar ga loop balik ke VPN
                        s.soTimeout = 4000
                        s.send(DatagramPacket(dns, dns.size, InetAddress.getByName(UPSTREAM), 53))
                        val rb = ByteArray(4096)
                        val p = DatagramPacket(rb, rb.size)
                        s.receive(p)
                        reply(pkt, ihl, rb.copyOf(p.length), out)
                    }
                } catch (_: Exception) { }
            }
        }
    }

    private fun isBlocked(name: String): Boolean {
        var d = name
        while (true) {
            if (d in blocked) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    private fun parseName(d: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val len = d[i].toInt() and 0xFF
            if (len == 0) return sb.toString().lowercase() to (i + 1)
            if (len and 0xC0 != 0 || i + 1 + len > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, len, Charsets.US_ASCII))
            i += len + 1
        }
        return null
    }

    // Bungkus payload DNS jadi paket IPv4/UDP balasan (src/dst dibalik)
    private fun reply(req: ByteArray, ihl: Int, payload: ByteArray, out: FileOutputStream) {
        val udpLen = 8 + payload.size
        val total = ihl + udpLen
        val r = ByteArray(total)
        System.arraycopy(req, 0, r, 0, ihl)
        System.arraycopy(req, 16, r, 12, 4)
        System.arraycopy(req, 12, r, 16, 4)
        r[2] = (total shr 8).toByte(); r[3] = total.toByte()
        r[8] = 64
        r[10] = 0; r[11] = 0
        val ck = checksum(r, ihl)
        r[10] = (ck shr 8).toByte(); r[11] = ck.toByte()
        r[ihl] = req[ihl + 2]; r[ihl + 1] = req[ihl + 3]
        r[ihl + 2] = req[ihl]; r[ihl + 3] = req[ihl + 1]
        r[ihl + 4] = (udpLen shr 8).toByte(); r[ihl + 5] = udpLen.toByte()
        // checksum UDP = 0 (boleh di IPv4)
        System.arraycopy(payload, 0, r, ihl + 8, payload.size)
        synchronized(out) { out.write(r) }
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun checksum(b: ByteArray, len: Int): Int {
        var s = 0L
        var i = 0
        while (i < len - 1) { s += u16(b, i); i += 2 }
        while (s shr 16 != 0L) s = (s and 0xFFFF) + (s shr 16)
        return (s.inv() and 0xFFFF).toInt()
    }

    override fun onRevoke() { stopSelf() }

    override fun onDestroy() {
        running = false
        try { tun?.close() } catch (_: Exception) { }
        tun = null
        pool.shutdownNow()
        super.onDestroy()
    }
}
